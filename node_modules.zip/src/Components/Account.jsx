const Account=()=>{
 return(
   <>
   <h1>My Account</h1>
   <div>Teju</div>
   
   </>

 );

}
export default Account;