import { useContext, useEffect, useState } from "react";
import Post from "./Post";
import { PostList as PostListData } from "../store/post-list-store";
import WelcomeMessage from "./WelcomeMessage";
import LoadingSpinner from "./LoadingSpinner";

const PostList = () => {
  const { postList, addInitialPosts } = useContext(PostListData);
  const [fetching, setFetching] = useState(false);

//useEffect(fun,[empty means runs at only once])
  useEffect(() => {
    setFetching(true);
    const controller = new AbortController();
    const signal = controller.signal;  //signal is the member of AbortControler

    fetch("https://dummyjson.com/posts", {signal}) //(url,method(get/post))
      .then((res) => res.json())
      .then((data) => {
        addInitialPosts(data.posts);
        setFetching(false);
      });

    return () => {   //Cleanup using returning something
      console.log("Cleaning up UseEffect."); //component dies/goes
      controller.abort();   //api cl abotrted
    };
  }, []);

  return (
    <>
      {fetching && <LoadingSpinner />}
      {!fetching && postList.length === 0 && <WelcomeMessage  />}
      {!fetching && postList.map((post) => <Post key={post.id} post={post} />)}
    </>
  );
};

export default PostList;