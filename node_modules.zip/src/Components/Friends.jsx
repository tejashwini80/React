const Friends=()=>{
 return(
  <>
  <ul className="list-group friends ">
    <center className="blockquote">Messages</center>
  <li className="list-group-item d-flex justify-content-between align-items-center friend-name">
    Amar
    <span className="badge text-bg-primary rounded-pill">14</span>
  </li>
  <li className="list-group-item d-flex justify-content-between align-items-center friend-name">
  Aishwarya
    <span className="badge text-bg-primary rounded-pill">2</span>
  </li>
  <li className="list-group-item d-flex justify-content-between align-items-center friend-name">
 Ashwini
    <span className="badge text-bg-primary rounded-pill">1</span>
  </li>
  <li className="list-group-item d-flex justify-content-between align-items-center friend-name">
  Sangmesh
    <span className="badge text-bg-primary rounded-pill">1</span>
  </li>
  
  <li className="list-group-item d-flex justify-content-between align-items-center friend-name">
  Tejashwini
    <span className="badge text-bg-primary rounded-pill">14</span>
  </li>
  <li className="list-group-item d-flex justify-content-between align-items-center friend-name">
    Tanuja
    <span className="badge text-bg-primary rounded-pill">2</span>
  </li>
  <li className="list-group-item d-flex justify-content-between align-items-center friend-name">
    Triveni
    <span className="badge text-bg-primary rounded-pill">1</span>
  </li>
  <li className="list-group-item d-flex justify-content-between align-items-center friend-name">
   MA
    <span className="badge text-bg-primary rounded-pill">14</span>
  </li>
  <li className="list-group-item d-flex justify-content-between align-items-center friend-name">
   PA
    <span className="badge text-bg-primary rounded-pill">2</span>
  </li>
  <li className="list-group-item d-flex justify-content-between align-items-center friend-name">
    Amma
    <span className="badge text-bg-primary rounded-pill">1</span>
  </li>
  <li className="list-group-item d-flex justify-content-between align-items-center friend-name">
     Appaji
    <span className="badge text-bg-primary rounded-pill">1</span>
  </li>
  
  
</ul></>
 );
}
export default Friends;